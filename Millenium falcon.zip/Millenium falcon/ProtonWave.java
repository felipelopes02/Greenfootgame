import greenfoot.*;
import java.util.List;

/**
 * A explosão quando uma nave é explodida
 */
public class ProtonWave extends Actor
{
    /** O dano que a explosão vai dar */
    private static final int DAMAGE = 30;
    
    /** Quantas imagens são ultilizadas na animação */
    private static final int NUMBER_IMAGES= 30;
    
    /** 
     * Imagens estaticas replicadas para cada objeto
     */
    private static GreenfootImage[] images;
    
    /** Imagem mostrada como index */
    private int currentImage = 0;
    
    /**
     * Cria uma nova explosão
     */
    public ProtonWave() 
    {
        initializeImages();
        setImage(images[0]);
        Greenfoot.playSound("proton.wav");
    }
    
    /** 
     * Cria as imagens da expansão da onda
     */
    public static void initializeImages() 
    {
        if (images == null) 
        {
            GreenfootImage baseImage = new GreenfootImage("wave.png");
            images = new GreenfootImage[NUMBER_IMAGES];
            for (int i = 0; i < NUMBER_IMAGES; i++) 
            {
                int size = (i+1) * ( baseImage.getWidth() / NUMBER_IMAGES );
                images[i] = new GreenfootImage(baseImage);
                images[i].scale(size, size);
            }
        }
    }
    
    /**
     * Verifica o quanto cresce e quando bate em algo
     */
    public void act()
    { 
        checkCollision();
        grow();
    }
    
    /**
     * Explode os asteroids
     */
    private void checkCollision()
    {
        int range = getImage().getWidth() / 2;
        List<Asteroid> asteroids = getObjectsInRange(range, Asteroid.class);     
        
        for (Asteroid a : asteroids) 
        {
            a.hit (DAMAGE);
        }
    }

    /**
     * Quando chegar no tamanho full é removida
     */
    private void grow()
    {
        if (currentImage >= NUMBER_IMAGES) 
        {
            getWorld().removeObject(this);
        }
        else 
        {
            setImage(images[currentImage]);
            currentImage++;
        }
    }
}
