import greenfoot.*; 

/**
 * Bala atirada pelo foguete

 */
public class Bullet extends SmoothMover
{
    /** O dano que a munição dá */
    private static final int damage = 16;
    
    /** Tamanho da munição */
    private int life = 30;
    
    public Bullet()
    {
    }
    
    public Bullet(Vector speed, int rotation)
    {
        super(speed);
        setRotation(rotation);
        addToVelocity(new Vector(rotation, 15));
        Greenfoot.playSound("EnergyGun.wav");
    }
    
    /**
     * Calcula o dano dado ao asteroid qunado acertado
     */
    public void act()
    {
        if(life <= 0) {
            getWorld().removeObject(this);
        } 
        else {
            life--;
            move();
            checkAsteroidHit();
        }
    }
    
    /**
     * Verifica quando acertamos o asteroid
     */
    private void checkAsteroidHit()
    {
        Asteroid asteroid = (Asteroid) getOneIntersectingObject(Asteroid.class);
        if (asteroid != null) 
        {
            getWorld().removeObject(this);
            asteroid.hit(damage);
        }
    }
}