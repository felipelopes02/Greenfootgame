import greenfoot.*; 


/**
 * Um botão no qual quando apertado aumenta a velocidade do jogo 
 * 
*/
public class Counter extends Actor
{
    private static final Color transparent = new Color(0,0,0,0);
    private GreenfootImage background;
    private int value;
    private int target;
    private String prefix;
    
    public Counter()
    {
        this(new String());
    }

    /**
     * Cria o botão inicializado em 0
     */
    public Counter(String prefix)
    {
        background = getImage();  // get image from class
        value = 0;
        target = 0;
        this.prefix = prefix;
    }
    
    /**
     * Função do botão para qunado clicado aumentar a velocidade
     */
    public void act() 
    {
      
        if (Greenfoot.mouseClicked(this)) {
            Greenfoot.setSpeed(55);// Add
            
            int currentSpeed = 55;
    
    GreenfootImage updatedImage = new GreenfootImage(background);
        updatedImage.drawString("DIFICIL: " + currentSpeed, 10, 30);
        setImage(updatedImage);
    }
    
    
}
}
        
        

    