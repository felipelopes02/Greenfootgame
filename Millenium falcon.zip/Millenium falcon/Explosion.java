import greenfoot.*;

/**
 * Faz uma explosão que aumenta quando efetuada
 * 
 */
public class Explosion extends Actor
{
    /** Quantas imagens devem ser usadas na explosão */
    private final static int IMAGE_COUNT= 12;
    
    /** 
     * Imagens estaticas que se reproduzem a cada objeto
     */
    private static GreenfootImage[] images;
    
    /** Tamanho da explosão atual*/
    private int imageNo = 0;
    
    /** Quanto a explosão aumenta na index */
    private int increment=1;
    
    /**
Cria uma nova Explosão
     */
    public Explosion() 
    {
        initializeImages();
        setImage(images[0]);
        Greenfoot.playSound("MetalExplosion.wav");
    }    
    
    /** 
     * Cria as imagens de explosão
     */
    public synchronized static void initializeImages() 
    {
        if(images == null) 
        {
            GreenfootImage baseImage = new GreenfootImage("explosion-big.png");
            images = new GreenfootImage[IMAGE_COUNT];
            for (int i = 0; i < IMAGE_COUNT; i++)
            {
                int size = (i+1) * ( baseImage.getWidth() / IMAGE_COUNT );
                images[i] = new GreenfootImage(baseImage);
                images[i].scale(size, size);
            }
        }
    }
    
    /**
     * Explosão
     */
    public void act()
    { 
        setImage(images[imageNo]);

        imageNo += increment;
        if(imageNo >= IMAGE_COUNT) 
        {
            increment = -increment;
            imageNo += increment;
        }
        
        if(imageNo < 0) 
        {
            getWorld().removeObject(this);
        }
    }
}