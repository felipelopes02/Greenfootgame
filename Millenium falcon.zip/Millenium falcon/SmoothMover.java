import greenfoot.*;  // (World, Actor, GreenfootImage, and Greenfoot)

/**
 * Verifica precisamente a localização do ator através de coordenadas duplas
 * 
 */
public abstract class SmoothMover extends Actor
{
    private Vector velocity;
    
    private double exactX;
    private double exactY;
    
    public SmoothMover()
    {
        this(new Vector());
    }
    
    /**
     * Cria um novo mover com a velocidade dada
     */
    public SmoothMover(Vector velocity)
    {
        this.velocity = velocity;
    }
    
    /**
     * Move na velocidade do vetor o ator para qualquer direção e quando o ator 
     * sai da tela joga ele novamente para o lado oposto da tela
     */
    public void move() 
    {
        exactX = exactX + velocity.getX();
        exactY = exactY + velocity.getY();
        if (exactX >= getWorld().getWidth()) {
            exactX = 0;
        }
        if (exactX < 0) {
            exactX = getWorld().getWidth() - 1;
        }
        if (exactY >= getWorld().getHeight()) {
            exactY = 0;
        }
        if (exactY < 0) {
            exactY = getWorld().getHeight() - 1;
        }
        super.setLocation((int) exactX, (int) exactY);
    }
    
    /**
     * Nos da a localizção
     */
    public void setLocation(double x, double y) 
    {
        exactX = x;
        exactY = y;
        super.setLocation((int) x, (int) y);
    }
    
    /**
     * Bota a localizção default do ator principal
     */
    public void setLocation(int x, int y) 
    {
        exactX = x;
        exactY = y;
        super.setLocation(x, y);
    }

    /**
     * Devolve exatamente a coordenada X
     */
    public double getExactX() 
    {
        return exactX;
    }

    /**
     * Retorna exatamente a coordenada Y
     */
    public double getExactY() 
    {
        return exactY;
    }

    /**
     * Modifica a velocidade através de outro vetor
     */
    public void addToVelocity(Vector boost) 
    {
        velocity.add(boost);
    }
    
    /**
     * Fatores menores que 1 irão desacelerar o ator principal
     */
    public void accelerate(double factor)
    {
        velocity.scale(factor);
        if (velocity.getLength() < 0.15) 
        {
            velocity.setNeutral();
        }
    }
    
    /**
     * Retorna a velocidade do ator
     */
    public double getSpeed()
    {
        return velocity.getLength();
    }
    
    /**
     * Reverte a velocidade horizontalmente
     */
    public void invertHorizontalVelocity()
    {
        velocity.revertHorizontal();
    }
    
    /**
     * Reverte a velocidade verticalmente
     */
    public void invertVerticalVelocity()
    {
        velocity.revertVertical();
    }
    
    /**
     * Retorna a velocidade atual
     */
    public Vector getVelocity() 
    {
        return velocity.copy();
    }
}
