import greenfoot.*;

/**
 * Asteroids
 */
public class Asteroid extends SmoothMover
{
    /** Tamanho do asteroid*/
    private int size;

    /** Quando estabilidade = 0 o asteroid explode */
    private int stability;


    /**
     * Cria um asteroid de tamanho default porem com movimentação aleatoria
     */
    public Asteroid()
    {
        this(50);
    }
    
    /**
     * Da a movimentação aleatoria para o asteroid
     */
    public Asteroid(int size)
    {
        super(new Vector(Greenfoot.getRandomNumber(360), 2));
        setSize(size);
    }
    
    /**
     * Cria os ateroids menores qunado explodidos
     */
    public Asteroid(int size, Vector velocity)
    {
        super(velocity);
        setSize(size);
    }
    
    public void act()
    {         
        move();
    }

    /**
     * Gera a estabilidade dos meteoros menores, sendo eles menos estaveis
     */
    public void setSize(int size) 
    {
        stability = size;
        this.size = size;
        GreenfootImage image = getImage();
        image.scale(size, size);
    }

    /**
     * Retorna a estabilidade atual do asteroid
     */
    public int getStability() 
    {
        return stability;
    }
    
    /**
     * Calcula o dano recebido pelo asteroid
     */
    public void hit(int damage) 
    {
        stability = stability - damage;
        if (stability <= 0) 
        {
            breakUp();
        }
    }
    
    /**
     * Quebra o asteroid e transforma em varios menores
     */
    private void breakUp() 
    {
        Greenfoot.playSound("Explosion.wav");
        
        if (size <= 16) {
            getWorld().removeObject(this);
        }
        else {
            int r = getVelocity().getDirection() + Greenfoot.getRandomNumber(45);
            double l = getVelocity().getLength();
            Vector speed1 = new Vector(r + 60, l * 1.2);
            Vector speed2 = new Vector(r - 60, l * 1.2);        
            Asteroid a1 = new Asteroid(size/2, speed1);
            Asteroid a2 = new Asteroid(size/2, speed2);
            getWorld().addObject(a1, getX(), getY());
            getWorld().addObject(a2, getX(), getY());        
            a1.move();
            a2.move();
        
            getWorld().removeObject(this);
        }
    }
}
